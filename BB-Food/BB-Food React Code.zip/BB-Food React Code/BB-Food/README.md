# React + Vite  Project Name: BB-Food  <br> <br>

This template provides a minimal setup to get React working in Vite with HMR and some ESLint rules. <br> <br>

Currently, two official plugins are available: <br>

- [@vitejs/plugin-react](https://github.com/vitejs/vite-plugin-react/blob/main/packages/plugin-react/README.md) uses [Babel](https://babeljs.io/) for Fast Refresh   <br>
- [@vitejs/plugin-react-swc](https://github.com/vitejs/vite-plugin-react-swc) uses [SWC](https://swc.rs/) for Fast Refresh   <br> <br> <br>
#   b 9 a 7 - c h e f s - t a b l e - S a d a t R i y a d       <br> <br>

Github code link: https://github.com/programming-hero-web-course1/b9a7-chefs-table-SadatRiyad      <br>
Live link 1 from surge:  https://PH-Assignment7-SadatRiyad.surge.sh            <br>
Live link 2 from netlify: https://ph-assignment7-sadatriyad.netlify.app         <br>

 
 
