/* eslint-disable react/prop-types */

const Li = ({ i }) => {
    // console.log(i)
    return (
        <li className="text-tertiary text-sm mb-1 font-firaSans">* {i}</li>
    );
};

export default Li;